package com.example.racketrivals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment


class HomeScreenFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home_screen, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Assuming your button's ID in the layout is "buttonId"
        val submitCourtButton = view.findViewById<Button>(R.id.submitCourtLocationButton)
        submitCourtButton.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, CourtSubmissionFragment())
            transaction.addToBackStack(null)
            transaction.commit()

        }
        val voteButton = view.findViewById<Button>(R.id.voteCourtLocationButton)
        voteButton.setOnClickListener {
            val transaction = requireActivity().supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, CourtVotingFragment())
            transaction.addToBackStack(null)
            transaction.commit()

        }

    }
}