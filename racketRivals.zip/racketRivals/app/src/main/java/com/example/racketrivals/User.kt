import kotlinx.serialization.Serializable

@Serializable
data class User(
    val elo: Int,
    val full_name: String,
    val avatar_url: String
    // Include other fields as necessary
)