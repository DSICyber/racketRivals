package com.example.racketrivals

import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView

class CourtViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    private val buttonValid: Button = itemView.findViewById(R.id.buttonValid)
    private val buttonInvalid: Button = itemView.findViewById(R.id.buttonInvalid)
    private val buttonDetails: Button = itemView.findViewById(R.id.buttonDetails)

    fun bind(court: RetrievedPotentialCourt) {

        val tag = court.possible_court_location_id

        buttonValid.tag = tag
        buttonInvalid.tag = tag
        buttonDetails.tag = tag

        buttonValid.setOnClickListener {
            // Handle Valid click
        }
        buttonInvalid.setOnClickListener {
            // Handle Invalid click
        }
        buttonDetails.setOnClickListener {
            // Handle More Details click
        }
    }
}


