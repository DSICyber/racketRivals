package com.example.racketrivals

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.racketrivals.SupabaseClientManager.client
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class CourtVotingFragment : Fragment() {
    private lateinit var adapter: CourtListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_court_voting, container, false)


    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tvEmptyMessage: TextView = view.findViewById(R.id.tvEmptyMessage)
        lifecycleScope.launch(Dispatchers.IO) {
            try{

                val potentialCourts = client.postgrest["Possible Court Locations"]
                    .select(Columns.list("possible_court_location_id,lights,admission_cost,status,court_name,court_coordinates,status"))
                    { eq("status", "UNDECIDED") }.decodeList<RetrievedPotentialCourt>()
                withContext(Dispatchers.Main) {

                }



            }catch (e:Exception){
                Log.e("ExceptionTag", "An error occurred: ${e.message}", e)

            }
        }



    }




        private fun handleButtonClick(courtId: String, action: String) {
            // Handle the button click here, courtId is the unique identifier
        }
    }



