package com.example.racketrivals

import User
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.gotrue.gotrue
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder

// UserSignInActivity.kt
class UserSignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_sign_in_main_screen)
        val fragment = HomeScreenFragment() // The fragment you want to switch to

        val fragmentManager = supportFragmentManager // Use supportFragmentManager in AppCompatActivity
        val fragmentTransaction = fragmentManager.beginTransaction()

        fragmentTransaction.replace(R.id.fragment_container, fragment)
        fragmentTransaction.addToBackStack(null) // Optional: Add this transaction to the back stack
        fragmentTransaction.commit()


        val client =SupabaseClientManager.client
        lifecycleScope.launch(Dispatchers.IO) {
            try{
                val user = client.gotrue.retrieveUserForCurrentSession(updateSession = true)
                val fileName = URLEncoder.encode(user.email, "UTF-8") + ".png"
                val bucket = client.storage["avatars"]
                val bytes = bucket.downloadAuthenticated(fileName)
                val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                val userDetails= client.postgrest["profiles"].select(columns= Columns.list("avatar_url,full_name,elo")){
                   eq("avatar_url",fileName)
                }.decodeSingle<User>()
                withContext(Dispatchers.Main) {
                    val eloLabelTextView: TextView = findViewById(R.id.eloLabelTextView)
                    val usernameTextView: TextView = findViewById(R.id.usernameTextView)
                val imageView: ImageView = findViewById(R.id.profileImageView)
                    eloLabelTextView.text = userDetails.elo.toString()
                    usernameTextView.text = userDetails.full_name
                imageView.setImageBitmap(bitmap)}


            }catch (e:Exception){
                Log.e("ExceptionTag", "An error occurred: ${e.message}", e)

            }


        }
    }


}




