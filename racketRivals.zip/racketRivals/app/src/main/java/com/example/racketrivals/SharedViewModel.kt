package com.example.racketrivals

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.android.gms.maps.model.LatLng

class SharedViewModel : ViewModel() {
    val selectedLocation: MutableLiveData<LatLng> = MutableLiveData()
}